export interface Product{
    name:string;
    price:number;
    category:string;
    color:string;
    description:string;
    image:string;
}