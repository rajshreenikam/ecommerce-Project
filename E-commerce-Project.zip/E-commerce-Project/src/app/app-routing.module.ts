import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AuthGuard } from './auth.guard';
import { CandeactivateGuard } from './candeactivate.guard';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { SearchComponent } from './search/search.component';
import { UserLoginComponent } from './user-login/user-login.component';

const routes: Routes = [
  {path:'', component:HomeComponent},
  {path:'userlogin', component:UserLoginComponent},
  {path:'adminlogin', component:AdminloginComponent},
  {path:'home',component:HomeComponent},
  {path:'addProduct',component:AddProductComponent,canActivate:[AuthGuard],canDeactivate:[CandeactivateGuard]},
  {path:'productDetails/:id', component:ProductDetailsComponent},
  {path:'search/:query',component:SearchComponent}, 
  {path:'**',component:PageNotFoundComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
