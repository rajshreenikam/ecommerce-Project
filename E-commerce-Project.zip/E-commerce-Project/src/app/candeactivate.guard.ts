import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AddProductComponent } from './add-product/add-product.component';
export interface CanComponentLeave {
  canLeave: () => boolean
 }
@Injectable({
  providedIn: 'root'
})
export class CandeactivateGuard implements CanDeactivate<AddProductComponent>  {
  canDeactivate(component: AddProductComponent) {
    if (component.canLeave) {
      return component.canLeave()
    }
    return true;
  }
}
