import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/data-type';
import { ProductService } from '../services/product.service';

 

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
  searchResult:any|Product;
  constructor(private activateRoute: ActivatedRoute, private product:ProductService, private router:Router){}

  ngOnInit(){
    let query=this.activateRoute.snapshot.paramMap.get('query');
    console.log(query);
    this.product.searchProduct(query).subscribe((result)=>{
      this.searchResult=result;
  })

}
breadCrumbSearch() {
  this.router.navigate([`search/${this.searchResult[0].category}`])

}
}
