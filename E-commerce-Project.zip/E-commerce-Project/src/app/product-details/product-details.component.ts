import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  id: any;
  productDetails: any;
  constructor(private _Activatedroute: ActivatedRoute, private product: ProductService, private router: Router) {

  }
  ngOnInit(): void {
    this.id = this._Activatedroute.snapshot.paramMap.get("id");
    this.product.getProductDetails(this.id).subscribe((res: any) => {
      this.productDetails = res;
      // console.log(res);

    })
  }
  breadCrumbSearch() {
    this.router.navigate([`search/${this.productDetails[0].category}`])
  }
  addToCart(){
    if(!localStorage.getItem('userlogin')){
      console.log( this.productDetails);
    } 
    
  }
}
