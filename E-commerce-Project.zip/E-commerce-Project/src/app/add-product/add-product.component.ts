import { Component, OnInit ,ViewChild} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Product } from 'src/data-type';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  
 public addProductForm!:FormGroup
  addProducMessage:string|undefined
  producList:undefined|Product
  isDirty = false;

  category: any = ['Electronic', 'Home Appliances', 'Mobile', 'Fashion','Toys','Grocery']
  displayedColumns: string[] = [
    'id',
     'name', 
     'price', 
     'category',
     'color',
     'description',
     'image',
    ];

    dataSource!: MatTableDataSource<any>;

    @ViewChild(MatPaginator) paginator!: MatPaginator;


  constructor(private formBuilder:FormBuilder, private product:ProductService){
    this.getProductList()
  }

  ngOnInit(): void {
     this.addProductForm=this.formBuilder.group({
      name:['',Validators.required],
      price:['',Validators.required,Validators, Validators.pattern("^[0-9]*$")],
      category:['',Validators.required],
      color:['',Validators.required],
      description:['',Validators.required],
      image:['',Validators.required],
     })
    
    this.addProductForm.valueChanges.subscribe((e: boolean) => this.isDirty = true);

  }
 canLeave() {
 if (this.isDirty) {
return window.confirm('You have some unsaved changes.Save it before leaving')
// alert("You have some unsaved changes.Save it before leaving");
 }
return true
}




  submit(data:Product  ){
    console.log(data);
    this.product.addProduct(data).subscribe((result)=>{
      console.log(result);
      if(result){
        this.addProducMessage="Product is successfully added"
      }
      setTimeout(()=>this.addProducMessage=undefined,3000)
    });
  }
  getProductList(){
    this.product.getProductList().subscribe({
      next:(res)=>{
        console.log(res);
        this.dataSource=new MatTableDataSource(res);
        this.dataSource.paginator=this.paginator;
      }
    })
  }
}
