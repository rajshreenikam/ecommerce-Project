import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';
 

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
public loginForm!:FormGroup;
userAuthError:string='';
  subscription: any;
 
constructor(private formBuilder:FormBuilder, private router:Router, private http:HttpClient,
  private login:LoginService,){}
 
ngOnInit(): void {
 
    this.loginForm= this.formBuilder.group({
      email:['',[Validators.required,Validators.email]],
      password:['',[Validators.required,Validators.minLength(8),this.createPasswordValidator()]]
    })
      this.login.reloadAdmin()
   
  }
    // ngOnDestroy(){
    //   this.subscription.unsubscribe();
    // }
  createPasswordValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) {
        return null;
      }
      const hasUpperCase = /[A-Z]+/.test(value);
      const hasLowerCase = /[a-z]+/.test(value);
      const specialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(value);
      const hasNumeric = /[0-9]+/.test(value);
      const passwordValid = hasUpperCase && hasLowerCase && specialChar && hasNumeric;
      return !passwordValid ? { passwordStrength: true } : null;
    }
  }  


  submitLoginForm(data:any){   
    this.userAuthError="";
     this.login.userLogin(data.value);
     this.login.isUserLoginError.subscribe((err)=>{
      if(err){
        this.userAuthError="Unknown User Name and Password";
      }
     })
      // if(this.loginForm.value.email==="raj@gmail.com" && this.loginForm.value.password==="Raj@1234")
      // { 
      //   this.router.navigate(['home']);
      //   console.log("Login successfully");
      // }
      // console.log("user not found");
    }

    
}

