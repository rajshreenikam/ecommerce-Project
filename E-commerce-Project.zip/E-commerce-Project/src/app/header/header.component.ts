import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from 'src/data-type';
import { LoginService } from '../services/login.service';
import { ProductService } from '../services/product.service';
import { SharedService } from '../services/shared.service';
 

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  subscription;
  userDetails: any = "";
  searchResult: any | Product[];
  item: any
  constructor(private route: Router, public login: LoginService, private ss: SharedService, private product: ProductService) {
    this.subscription = this.ss.currentMessage.subscribe((user) => {
      this.userDetails = user;
      console.log("-------->user",user)
      // console.log("****************", this.userDetails)
    })

  }

  ngOnInit(): void {

  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  logoutUser() {
    // this.login.removeUser();
    this.ss.changeMessage("")
    this.userDetails = ""
    localStorage.clear();
    this.route.navigate(['userlogin'])
  }
   

  searchProduct(query: KeyboardEvent) {
    if (query) {
      const element = query.target as HTMLInputElement;
      // console.log(element.value);
      this.product.searchProduct(element.value).subscribe((result) => {
        // console.log(result);
        this.searchResult = result;
      })
    }
  }
  hideSearch() {
    this.searchResult = undefined;
  }

  submitSearch(value: string) {
    console.log(value);
    this.route.navigate([`search/${value}`]);
  }

  addToCart(){
    
  }
}

