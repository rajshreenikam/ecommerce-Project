import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { SharedService } from './shared.service';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  isUserLoginError = new EventEmitter<boolean>(false);
  isUserAdminError = new EventEmitter<boolean>(false);
  isAdminLoggedIn = new BehaviorSubject<boolean>(false);

  constructor(
    private http: HttpClient,
    private router: Router,
    private ss: SharedService,
    private toastr: ToastrService
  ) {}

  userLogin(data: any) {
    console.log(data);
    this.http
      .get(
        `http://localhost:3000/user?email=${data.email}&password=${data.password}`,
        { observe: 'response' }
      )
      .subscribe((result: any) => {
        this.ss.changeMessage(result.body);
        //  console.log(result);
        if (result && result.body && result.body.length) {
          console.log('user Logged In');
          this.toastr.success('User Login Successfully');
          localStorage.setItem('userlogin', JSON.stringify(result.body));
          this.router.navigate(['home']);
        } else {
          console.log('User login fail');
          this.toastr.warning('User not Login Successfully, Try again');
          this.isUserLoginError.emit(data);
        }
      });
  }

  adminLogin(data: any) {
    console.log(data);
    this.http
      .get(
        `http://localhost:3000/admin?email=${data.email}&password=${data.password}`,
        { observe: 'response' }
      )
      .subscribe((result: any) => {
        //  console.log(result);
        this.isAdminLoggedIn.next(true);
        this.ss.changeMessage(result.body);
        if (result && result.body && result.body.length) {
          console.log('Admin Logged In');
          this.toastr.success('Admin Login Successfully');
          localStorage.setItem('userlogin', JSON.stringify(result.body));
          this.router.navigate(['addProduct']);
        } else {
          console.log('User login fail');
          this.toastr.warning('Admin not Login Successfully, Try again');
          this.isUserAdminError.emit(data);
        }
      });
  }
  reloadAdmin() {
    if (localStorage.getItem('userlogin')) {
      this.isAdminLoggedIn.next(true);
      this.router.navigate(['userlogin']);
    }
  }
}
