import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { getMatIconFailedToSanitizeLiteralError } from '@angular/material/icon';
import { Observable, observable } from 'rxjs';
import { Product } from 'src/data-type';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  constructor(private http: HttpClient) {}

  // getproduct(){
  //   return this.http.get<any>("https://fakestoreapi.com/products/")
  // }

  addProduct(data: Product) {
    console.log('service called');
    return this.http.post('http://localhost:3000/products', data);
  }

  getProductList(): Observable<any> {
    return this.http.get<Product>('http://localhost:3000/products');
  }

  getProductDetails(id: any) {
    return this.http.get<Product>(`http://localhost:3000/products?id=${id}`);
  }

  searchProduct(query: any) {
    return this.http.get<Product>(`http://localhost:3000/products?q=${query}`);
  }

  // localAddToCart(data:Product){
  //   let cartData=[];
  //   let localCart=localStorage.getItem('localCart');
  //   if()

  // }
}
