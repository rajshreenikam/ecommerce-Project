import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';
import { SharedService } from '../services/shared.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  public adminLoginForm!:FormGroup;
  adminAuthError:string='';
  subscription: any;

  constructor(private formBuilder:FormBuilder, 
              private router:Router,
              private login:LoginService,private ss:SharedService){}

   ngOnInit(): void {
     this.adminLoginForm=this.formBuilder.group({
        email:['',Validators.required],
        password:['',[Validators.required,Validators.minLength(8),this.createPasswordValidator]]
     })
   }
  //  ngOnDestroy(){
  //   this.subscription.unsubscribe();
  // }

   createPasswordValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) {
        return null;
      }
      const hasUpperCase = /[A-Z]+/.test(value);
      const hasLowerCase = /[a-z]+/.test(value);
      const specialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(value);
      const hasNumeric = /[0-9]+/.test(value);
      const passwordValid = hasUpperCase && hasLowerCase && specialChar && hasNumeric;
      return !passwordValid ? { passwordStrength: true } : null;
    }
  }  

   submitAdminLoginForm(data:any){
    this.login.adminLogin(data.value)
    this.login.isUserAdminError.subscribe((err)=>{
      if(err){
        this.adminAuthError="Unknown User Name and Password";
      }
    
   })
  }
}
