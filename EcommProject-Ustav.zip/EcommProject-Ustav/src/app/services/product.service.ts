import { query } from '@angular/animations';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { enviornment } from '../enviornments/enviornment';
import { product } from '../interface/ecom.interface';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private hostUrl = enviornment.hostUrl;
  constructor(private http: HttpClient) {

  }
  addProduct(data: product) {
    return this.http.post<product>(`${this.hostUrl}/products`, data)
  }
  getProductList() {
    return this.http.get<product>(`${this.hostUrl}/products`)
  }
  searchProducts(query: string) {
    return this.http.get<product>(`${this.hostUrl}/products?q=${query}`)
  }
  getProductDetails(id: any) {
    return this.http.get<product>(`${this.hostUrl}/products?id=${id}`)
  }
  deleteProduct(id: any) {
    return this.http.delete<product>(`${this.hostUrl}/products/${id}`)
  }
  getOffers() {
    return this.http.get(`${this.hostUrl}/offers`)
  }
}
