import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { enviornment } from '../enviornments/enviornment';
import { login } from '../interface/ecom.interface';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private hostUrl = enviornment.hostUrl;
  constructor(private http: HttpClient) {
  }
  userLogin(data: login) {
    return this.http.get(`${this.hostUrl}/user?uname=${data.uname}&password=${data.password}`)
  }
}
