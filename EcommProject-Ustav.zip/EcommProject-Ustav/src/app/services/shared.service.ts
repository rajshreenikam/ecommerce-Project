import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
    userLoginLogoutMsg = new BehaviorSubject('');
    searchMsg = new Subject();

    // currentMessage = this.messageSource.asObservable();
    toastMixin = Swal.mixin({
      toast: true,
      icon: 'success',
      title: 'General Title',
      position: 'top-right',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });
    fireAlert(title:string,icon1:any){
      this.toastMixin.fire({
        title: title,
        icon: icon1
      });
    }
    // canDeactivateMsg(){
    //   Swal.fire({
    //     title: 'Are you sure?',
    //     text: "You have some unsaved changes.Save it before leaving",
    //     icon: 'warning',
    //     showCancelButton: true,
    //     confirmButtonColor: '#3085d6',
    //     cancelButtonColor: '#d33',
    //     confirmButtonText: 'Yes, delete it!'
    //   }).then((result) => {
    //     if (result.isConfirmed) {
    //       Swal.fire(
    //         'Deleted!',
    //         'Your file has been deleted.',
    //         'success'
    //       )
    //     }
    //   })
    // }
  constructor() { 

  }
}
