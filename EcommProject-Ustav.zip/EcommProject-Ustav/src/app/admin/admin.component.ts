import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { faL } from '@fortawesome/free-solid-svg-icons';
import { ProductService } from '../services/product.service';
import { SharedService } from '../services/shared.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  productForm: any;
  isDirty = false;
  productList: any = []
  p: number = 1;
  itemsPerPage: number = 4;
  value = 'Clear me';

  constructor(private fb: FormBuilder, private productService: ProductService, private ss: SharedService) {

  }

  productsForm() {
    this.productForm = this.fb.group({
      name: ["", Validators.required],
      price: ["", Validators.required],
      color: ["", Validators.required],
      description: ["", Validators.required],
      imgUrl: ["", Validators.required],
      category: ["", Validators.required],
      brand: [""],
      warranty: [""],
      modelNumber: [""],
      fit: [""],
      fabric: [""],
      Sleeve: [""]
    })
    this.productForm.valueChanges.subscribe((e: boolean) => this.isDirty = true);
  }

  ngOnInit() {
    this.productsForm()
    this.getProductList();
  }
  getProductList() {
    this.productService.getProductList().subscribe((res) => {
      this.productList = res;
    })
  }
  onFire() {
    this.ss.fireAlert('sdkjckjsdc', 'success')
  }
  canLeave() {
    if (this.isDirty) {
      return window.confirm('You have some unsaved changes.Save it before leaving')
    }
    return true
  }
  addProduct() {
    this.isDirty = false;
    this.productService.addProduct(this.productForm.value).subscribe((res): any => {
      this.ss.fireAlert('New product added successfully', 'success')
      this.getProductList();
    })
  }
  deleteProduct(data: any) {
    this.productService.deleteProduct(data.id).subscribe((res): any => {
      this.ss.fireAlert('Product deleted successfully', 'success')
      this.getProductList();
    })
  }

}
