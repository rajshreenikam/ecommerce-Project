import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from "@angular/common";
import { Subscription } from 'rxjs';
import { SharedService } from '../services/shared.service';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  subscription!: Subscription;
  user: any;
  searchResults: any = []
  constructor(private router: Router, private ps: ProductService, private sharedService: SharedService) {

  }
  ngOnInit() {
    this.subscription = this.sharedService.userLoginLogoutMsg.subscribe((user) => {
      this.getUserDetails()
    })
  }
  ngOnDestroy() {
    this.user = "";
    this.subscription.unsubscribe();
  }
  getUserDetails() {
    var user: any = sessionStorage.getItem('user');
    this.user  = JSON.parse(user);
  }

  logout() {
    sessionStorage.clear();
    this.user = "";
    this.sharedService.fireAlert('Log out successfully', 'success')
    this.router.navigate(['login'])
  }

  searchProduct(query: KeyboardEvent) {
    if (query) {
      const element = query.target as HTMLInputElement;
      this.ps.searchProducts(element.value).subscribe((res: any) => {
        if (res.length > 5) {
          res.length = 5;
        }
        this.searchResults = res;
      })
    }
  }

  hideSearch() {
    this.searchResults = undefined;
  }
  onSearch(value: string) {    
    if(this.router.url.includes('/home/search')){
      console.log("---------->1");
      this.sharedService.searchMsg.next(value)
    }else{
      console.log("---------->2")
      this.router.navigate([`home/search/${value}`])
    }
  }
}
