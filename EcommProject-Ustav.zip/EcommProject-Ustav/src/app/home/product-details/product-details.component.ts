import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent {
  id
  productDetails: any;
  offers: any;
  constructor(private router: Router, private _Activatedroute: ActivatedRoute, private productService: ProductService) {
    this.id = this._Activatedroute.snapshot.paramMap.get("id");
  }
  ngOnInit() {
    this.getProductDetails();
    this.getOffers();
  }

  getProductDetails() {
    this.productService.getProductDetails(this.id).subscribe((res: any) => {
      this.productDetails = res[0];
    })
  }
  getOffers() {
    this.productService.getOffers().subscribe((res: any) => {
      this.offers = res;
    })
  }
  onSearch() {
    this.router.navigate([`home/search/${this.productDetails.category}`])
  }

}
