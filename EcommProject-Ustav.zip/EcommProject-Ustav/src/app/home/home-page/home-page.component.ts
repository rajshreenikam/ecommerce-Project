import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Route, Router } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { product } from '../../interface/ecom.interface';
@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent {
  productList: any = [];

  constructor(private route: Router, private productService: ProductService) {

  }
  ngOnInit() {
    this.getProductList()
  }
  getProductList() {
    this.productService.getProductList().subscribe((res) => {
      this.productList = res;
    })
  }

  showProductDetails(data: any) {
    this.route.navigate(['/details'])
  }
}
