import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { SharedService } from 'src/app/services/shared.service';
import { ProductService } from '../../services/product.service';
@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent {
  price =100;
  searchResults:any=[]
  query:any;
  subscription:Subscription 
  constructor(private sharedservice : SharedService,private activatedroute : ActivatedRoute,private ps : ProductService){
    this.subscription = this.sharedservice.searchMsg.subscribe((res)=>{
      this.searchProduct(res)
    })
  }
  ngOnInit(){
    this.query = this.activatedroute.snapshot.paramMap.get('query');
    this.searchProduct(this.query);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  searchProduct(value:any){
    this.ps.searchProducts(value).subscribe((res: any) => {
      this.searchResults = res;
      console.log(res)
    })
  }
}
