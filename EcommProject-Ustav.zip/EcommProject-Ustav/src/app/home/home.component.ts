import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Route, Router } from '@angular/router';
import { ProductService } from '../services/product.service';
import { product } from '../interface/ecom.interface';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  productList: any = [];

  constructor() {

  }

}
