import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { CartComponent } from './cart/cart.component';
import { AuthGuard } from './guards/auth.guard';
import { CandeactivateGuard } from './guards/candeactivate.guard';
import { AuthGuardService } from './guards/loginAutherized';
import { HomePageComponent } from './home/home-page/home-page.component';
import { HomeComponent } from './home/home.component';
import { ProductDetailsComponent } from './home/product-details/product-details.component';
import { SearchProductComponent } from './home/search-product/search-product.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path:'',redirectTo: '/login', pathMatch: 'full'},
  {path:'login',component:LoginComponent,canActivate:[AuthGuardService]},
  {path:'admin',component:AdminComponent,canActivate:[AuthGuard],canDeactivate:[CandeactivateGuard]},
  {path:'home',component:HomeComponent,
   children:[
    {path:'',component:HomePageComponent},
    {path:'details/:id',component:ProductDetailsComponent},
    {path:'search/:query',component:SearchProductComponent},
   ] 
  },
  {path:'cart',component:CartComponent},
  {path:'product-details/:id',component:ProductDetailsComponent},
  {path:'**',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
