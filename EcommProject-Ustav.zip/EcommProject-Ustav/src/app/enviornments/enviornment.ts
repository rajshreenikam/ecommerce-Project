export const enviornment ={
production : false,
hostUrl: 'http://localhost:3000'
}