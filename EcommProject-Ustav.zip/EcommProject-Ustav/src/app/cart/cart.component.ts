import { Component } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cartList =[
    { imgPath:"../../assets/img/laptop-g02804dba7_1920.jpg",
      title:"Lenovo IdeaPad Ryzen 5",
      description:"Lenovo IdeaPad Ryzen 5 Hexa Core 5600H - (8 GB/512 GB SSD/Windows 11 Home/4 GB Graphics/NVIDIA GeForce GTX 1650) 15ACH6 Gaming Laptop  (15.6 Inch, Black, 2.25 kg kg)",
      price:"49000",
      quantity:1,
      total:49000
    },
    {imgPath:"../../assets/img/laptop-g02804dba7_1920.jpg",
      title:"Lenovo IdeaPad Ryzen 5",
      description:"Lenovo IdeaPad Ryzen 5 Hexa Core 5600H - (8 GB/512 GB SSD/Windows 11 Home/4 GB Graphics/NVIDIA GeForce GTX 1650) 15ACH6 Gaming Laptop  (15.6 Inch, Black, 2.25 kg kg)",
      price:"49000",
      quantity:1,
      total:49000
    },
    {imgPath:"../../assets/img/laptop-g02804dba7_1920.jpg",
      title:"Lenovo IdeaPad Ryzen 5",
      description:"Lenovo IdeaPad Ryzen 5 Hexa Core 5600H - (8 GB/512 GB SSD/Windows 11 Home/4 GB Graphics/NVIDIA GeForce GTX 1650) 15ACH6 Gaming Laptop  (15.6 Inch, Black, 2.25 kg kg)",
      price:"49000",
      quantity:1,
      total:49000
    },
    {imgPath:"../../assets/img/laptop-g02804dba7_1920.jpg",
      title:"Lenovo IdeaPad Ryzen 5",
      description:"Lenovo IdeaPad Ryzen 5 Hexa Core 5600H - (8 GB/512 GB SSD/Windows 11 Home/4 GB Graphics/NVIDIA GeForce GTX 1650) 15ACH6 Gaming Laptop  (15.6 Inch, Black, 2.25 kg kg)",
      price:"49000",
      quantity:1,
      total:49000
    },
  ]
}
