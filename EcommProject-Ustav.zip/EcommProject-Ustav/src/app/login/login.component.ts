import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, ValidationErrors, ValidatorFn, Validators } from '@angular/forms'
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';
import { SharedService } from '../services/shared.service';
import { createPasswordStrengthValidator } from '../shared/url.validator';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: any;
  subscription: Subscription | undefined;

  constructor(private sharedService: SharedService, private data: SharedService, private fb: FormBuilder, private router: Router, private loginService: LoginService) {

  }
  ngOnInit() {
   sessionStorage.clear();
   this.data.userLoginLogoutMsg.next('login')
   this.loginFormCreate();

  }

  // Code for login form
  loginFormCreate(){
    this.loginForm = this.fb.group({
      uname: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8), createPasswordStrengthValidator]]
    });
  }
  
  // Code for login User
  loginUser() {
    this.loginService.userLogin(this.loginForm.value).subscribe((res: any) => {
      if (res.length != 0) {
        this.sharedService.fireAlert('Login successfully', 'success')
        sessionStorage.setItem('user', JSON.stringify(res[0]));
        this.data.userLoginLogoutMsg.next('login')
        if (res[0].type == 'enduser') {
          this.router.navigate(['home'])
        } else {
          this.router.navigate(['admin'])
        }
      } else {
        this.sharedService.fireAlert('Wrong Username or Password', 'error')
      }
    })
  }


}
