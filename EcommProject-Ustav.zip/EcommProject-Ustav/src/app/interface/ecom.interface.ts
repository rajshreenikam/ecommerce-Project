export interface login{
    uname:string;
    password:string
}

export interface product{
    name: string,
    price: number,
    color: string,
    description: string,
    imgUrl: string,
    category: string,
}