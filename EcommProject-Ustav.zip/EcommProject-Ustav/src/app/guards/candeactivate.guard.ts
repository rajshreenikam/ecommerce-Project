import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AdminComponent } from '../admin/admin.component';

export interface CanComponentLeave{
  canLeave:()=>boolean
  }

@Injectable({
  providedIn: 'root'
})


export class CandeactivateGuard implements CanDeactivate<CanComponentLeave> {
  canDeactivate(component: AdminComponent) {
    if (component.canLeave) {
      return component.canLeave()
    } 
    return true;
  }

}
